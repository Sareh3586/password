import re
p=input("input your password:")
x=True
while x:
      if(len(p)<6 or len(p)>12):
         break
      elif not re.search("[a-z]",p):
         break
      elif not re.search("[0-9]",p):
         break
      elif not re.search("[A-z]",p):
         break
      elif not re.search("[$#@]",p):
         break
      else:
         print("valid password")

         x=False
         break

if x:
         print("not a valid password")
